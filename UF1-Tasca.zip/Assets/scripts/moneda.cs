using UnityEngine;

public class Moneda : MonoBehaviour
{
    private float velocidadGiro = 1f;


    void FixedUpdate()
    {
        transform.Rotate(new Vector3(velocidadGiro, 0, 0));
    }
}
